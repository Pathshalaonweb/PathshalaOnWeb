<?php $this->load->view('admin/popup_header'); ?>
	<table width="100%"  border="0" cellspacing="5" cellpadding="5" class="list">
		 <thead>
		 <tr >
			<td  height="30"><?php echo $pageresult->help_title; ?></td>
		</tr>
		 </thead>
		<tr class="trOdd">
			<td width="100%"><?php echo $pageresult->help_desc;?> </td>
		</tr>
	</table>
</body>
</html>