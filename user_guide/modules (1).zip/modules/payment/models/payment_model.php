<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class payment_model extends MY_Model {
	
	/**
	 * Get account by id
	 *
	 * @access public
	 * @param string $account_id
	 * @return object account object
	 */
	 	
	

	
	
	
}
/* End of file member_model.php */
/* Location: ./application/modules/cart/models/cart_model.php */