<?php 
$route["users/logout"]               = "users/logout";
