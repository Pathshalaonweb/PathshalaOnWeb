
<div class="container">
	<div class="row">
		<div class="col-md-6 col-md-offset-3">
			<div class="form-group">
				<h1>Login with facebook</h1>
				<a href="<?php if(!empty($fburl)) echo $fburl;?>" class="socil btn btn-primary btn-lg btn-block">
					<span class="pull-left fa fa-facebook" aria-hidden="true"></span>
						Signup with Facebook
					</a>
			</div>
		</div>
	</div>
</div>




<div class="container">
	<div class="row">
		<h1 class="text-center">Demo | Login with facebook in codeigniter</h1>
		<div class="col-md-6 col-md-offset-3 tsccs">
			<div class="form-group">
			<br><br>
				<a href="<?php if(!empty($fburl)) echo $fburl;?>" class="socil btn btn-primary btn-lg btn-block">
					<span class="pull-left fa fa-facebook" aria-hidden="true"></span>
						Login with Facebook
					</a>
			</div>
		</div>
	</div>
</div>