<?php 

echo var_dump($_SESSION);

echo $_SESSION['first_name']

?>

<body>
<div>
  <h1>Welcome User</h1>
</div>
</body>
