<?php $this->load->view('top_application'); ?>
<section>
<div class="bg1 min-h mt5 p10">
<!--tree-->
<div class="mt5">
<h1>Advanced Search</h1>
<p class="tree mt10"><strong class="fs11 ttu">You are here :</strong> <a href="index.htm" class="home-icon"><img src="<?php echo theme_url(); ?>images/spacer.gif" width="16" alt=""></a> <span class="pr2 fs14">»</span> Advanced Search</p>
</div>
<!--tree-->

<div class="aj mt10">
  <div class="cb"></div>
<?php

$path = current_url_query_string();				 
echo form_open('search',array('name'=>"frm11",'method'=>'get')); ?>
<div class="mt25 fl w60">
<p class="mt20 fs18 ttu blue b ml10 orange">Advanced Search</p>
<div class="p15 mt10">
<p><label for="first_name">Keywords</label>
</p>
<p class="mt5"><input type="text" name="keyword" id="keyword" class="input-bdr2" style="width:430px;" value="<?php echo set_value('keyword');?>" >
</p>

<p class="mt5"><label for="last_name">Category</label>
</p>
<p class="mt5">

<select name="category_id" style="width:440px;" class="input-bdr2" >
<option value="">Select Category </option>
<?php echo get_nested_dropdown_menu(0);?>
</select>
</p>

<p class="mt5"><label for="email">Price Range</label>
</p>
<p class="mt5">
<select name="prange" id="select" style="width:440px;" class="input-bdr2">
<option value="">Select Price  Range </option>
<?php
foreach($priceRange as $key=>$val)
{
?>
<option value="<?php echo $key;?>"><?php echo $val;?> ($) </option>
<?php	
}
?>
</select>

<p class="mt15"><input type="submit" name="submit" id="button" value="Submit" class="blacklink1">
<input type="reset" name="reset" id="button2" value="Reset" class="blacklink1"></p>

</div>
</div>

 <?php echo form_close();?> 
 

<div class="fl w40 mt126"><img src="<?php echo theme_url(); ?>images/contact-img.jpg" alt=""></div>
<div class="cb"></div>

</div>

</div>
</section>
<?php $this->load->view('bottom_application'); ?>