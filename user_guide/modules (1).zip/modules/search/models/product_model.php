<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Product_model extends MY_Model
 {

		 
	 public function get_products($limit='10',$offset='0',$param=array())
	 {
		
		$category_id		=   @$param['category_id'];
		$status			    =   @$param['status'];	
		$productid			=   @$param['productid'];
		$orderby			=	@$param['orderby'];	
		$where			    =	@$param['where'];	
		$keyword			=   trim($this->input->post('keyword',TRUE));						
		$keyword			=   $this->db->escape_str($keyword);
		
		
		
		if($category_id!='')
		{
			$this->db->where("wlp.category_id ","$category_id");
		}
		
		if($productid!='')
		{
			$this->db->where("wlp.products_id  ","$productid");
		}
		
		if($status!='')
		{
			$this->db->where("wlp.status","$status");
		}
		
		if($where!='')
		{
			$this->db->where($where);
			
		}
		if($keyword!='')
		{
			$this->db->where("(wlp.product_name LIKE '%".$keyword."%' OR wlp.product_code LIKE '%".$keyword."%' )");
		}
		
		if($orderby!='')
		{		
			$this->db->order_by($orderby);
			
		}
		else
		{
			$this->db->order_by('wlp.products_id ','desc');
		}
	
	    $this->db->group_by("wlp.products_id"); 	
		$this->db->limit($limit,$offset);
		$this->db->select('SQL_CALC_FOUND_ROWS wlp.*,wlpm.media,wlpm.media_type,wlpm.is_default',FALSE);
		$this->db->from('wl_products as wlp');
		$this->db->where('wlp.status !=','2');
		$this->db->join('wl_products_media AS wlpm','wlp.products_id=wlpm.products_id','left');
		$q=$this->db->get();
		//echo_sql();
		$result = $q->result_array();	
		$result = ($limit=='1') ? $result[0]: $result;	
		return $result;
				
	}
		  
	public function get_product_media($limit='4',$offset='0',$param=array())
    {		  
		
		 $default			    =   @$param['default'];	
		 $productid			    =   @$param['productid'];
		 $media_type			=   @$param['media_type'];
		 		
		 if( is_array($param) && !empty($param) )
		 {			
			$this->db->select('SQL_CALC_FOUND_ROWS *',FALSE);
			$this->db->limit($limit,$offset);
			$this->db->from('wl_products_media');
			$this->db->where('products_id',$productid);	
			
			if($default!='')
			{
				$this->db->where('is_default',$default);	
			}
			if($media_type!='')
			{
				$this->db->where('media_type',$media_type);	
			}
							
			$q=$this->db->get();
			$result = $q->result_array();	
			$result = ($limit=='1') ? $result[0]: $result;	
			return $result;	
			
		 }				
		
	}
		
	public function related_products_added($productId,$limit='NULL',$start='NULL')
	{
		$res_data =  array();
		$condtion = ($productId!='') ? "status ='1' AND product_id = '$productId' ":"status ='1'";
		$fetch_config = array(
													'condition'=>$condtion,
													'order'=>"id DESC",
													'limit'=>$limit,
													'start'=>$start,							 
													'debug'=>FALSE,
													'return_type'=>"array"							  
												 );		
		$result = $this->findAll('wl_products_related',$fetch_config);
		if( is_array($result) && !empty($result) )
		{
			foreach ($result as $val )
			{ 
				$res_data[$val['id']] =$val['related_id'];
			}
		}
		return $res_data;		
	}
	
	
	
	public function get_related_products($productId)
	{
		$condtion = (!empty($productId)) ? "status !='2'  AND products_id NOT IN(".implode(",",$productId). ")" :"status !='2'";
				
		$fetch_config = array(
													'condition'=>$condtion,
													'order'=>"products_id DESC",
													'limit'=>'NULL',
													'start'=>'NULL',							 
													'debug'=>FALSE,
													'return_type'=>"array"							  
												 );		
		$result = $this->findAll('wl_products',$fetch_config);
		return $result;	
	}
	
	
	public function related_products($productId,$limit='NULL',$start='NULL')
	{
		$res_data =  array();
		$condtion = ($productId!='') ? "status ='1' AND product_id = '$productId' ":"status ='1'";
		$fetch_config = array(
													'condition'=>$condtion,
													'order'=>"id DESC",
													'limit'=>$limit,
													'start'=>$start,							 
													'debug'=>FALSE,
													'return_type'=>"array"							  
												 );		
		$result = $this->findAll('wl_products_related',$fetch_config);
		if( is_array($result) && !empty($result) )
		{
			foreach ($result as $val )
			{ 
			
				$res_data[$val['id']] = $this->get_products(1,0, array('productid'=>$val['related_id']));
				
				
			}
		}
		
		$res_data = array_filter($res_data);
		return $res_data;		
	}
	
	public function get_shipping_methods()
	{
		$condtion = "status =1";
		$fetch_config = array(
													'condition'=>$condtion,
													'order'=>"shipping_id DESC",							 					 
													'debug'=>FALSE,
													'return_type'=>"array"							  
													);		
		$result = $this->findAll('wl_shipping',$fetch_config);
		return $result;	
	}
	 
	  
}