<?php
class Search extends Public_Controller
{

	
	public function __construct()
	{
		parent::__construct();  		
		$this->load->model(array('category/category_model','products/product_model'));	
		$this->load->helper(array('products/product','category/category','query_string'));
	}

	public function index()
	{			
		 $posted_data = array_filter($this->input->get());
	     unset($posted_data['submit']);
		 
		 $condtion                = array();	
		 $where                   = "";
		 $condtion['status']     = '1';
		 
		 $pagesize               =  (int) $this->input->get_post('pagesize');
		 
	     $config['limit']		 =  ( $pagesize > 0 ) ? $pagesize : $this->config->item('per_page');
		 		 		 
		 $offset                 =  ( $this->input->get_post('per_page') > 0 ) ? $this->input->get_post('per_page') : 0;			
		 $base_url               =   current_url_query_string(array('filter'=>'result'),array('per_page'),array('pagesize'));
		 
	
		if( is_array($posted_data) && !empty($posted_data ))
		{
				$category_id            = (int) $this->input->get_post('category_id',TRUE);
				$prange                 =  $this->input->get_post('prange',TRUE);
		
			if($category_id!='' )
			{	
				
			  $condtion['category_id'] = $category_id;
			  
			  
			}		
			
			if($prange!='' )
			{	
			    
			        	if(strstr($prange,"-"))
						{
							$arr_price=explode("-",$prange);
							
							
							$where.="(if(wlp.product_discounted_price='0.0000', wlp.product_price,wlp.product_discounted_price )>='".$arr_price[0]."' AND if(wlp.product_discounted_price='0.0000', wlp.product_price,wlp.product_discounted_price )<='".$arr_price[1]."')";
							
							/*if(is_numeric($arr_price[0]))
							{
								$where.="( wlp.product_price>='$arr_price[0]' OR ( wlp.product_discounted_price>='$arr_price[0]' AND product_discounted_price!='0.0000') ) ";
							}
							
							
							if(is_numeric($arr_price[1]))
							{
								$where.="AND ( wlp.product_price<='$arr_price[1]' OR ( wlp.product_discounted_price<='$arr_price[1]' AND product_discounted_price!='0.0000')) ";
								
							}*/
							
							
						}elseif( strstr($prange,">" ))
						{
							$arr_price=explode(">",$prange);
							
							if(is_numeric($arr_price[1]))
							{
								$where.="(wlp.product_price>='$arr_price[1]' or (wlp.product_discounted_price>='$arr_price[1]' AND  product_discounted_price!='0.0000')) ";
							}
							
						}elseif(strstr($prange,"&lt;"))
						{
							$arr_price=explode("&lt;",$prange);
							
							if(is_numeric($arr_price[1]))
							{
								$where.="(wlp.product_price<='$arr_price[1]' or (wlp.product_discounted_price<='$arr_price[1]' AND  product_discounted_price!='0.0000')) ";
								
							}
							
						}						
						
			       $condtion['where'] = $where;
					
			}		  
		   
		}
		
		   $res_array                =  $this->product_model->get_products($config['limit'],$offset,$condtion);		
		   $config['total_rows']     =  get_found_rows();	
		   $data['res']              =  $res_array; 			
		   $data['page_links']       =  pagination_refresh($base_url,$config['total_rows'],$config['limit'],$offset);	 	
		   $data['heading_title']    = "Search Result";   
		   $this->load->view('search/search_result_view',$data);
		
		
	}
	
	
   public function advance_search()
   {
	   
	    $priceOpts = array("0-100"=>"0-100","101-500"=>"101-500","501-1000"=>"501-1000",">1000"=>">1000");	   
	    $data['heading_title'] = "Advanced Search";	
		$data['priceRange']   = $priceOpts;		
		$this->load->view('search/advance_search_view',$data);
		
	   
   }
	
	
	
}
?>