<?php
//$route['products/detail/(:num)']    = 'products/detail/$1';
//$route['products/(:any)']           = 'products/index/$1';
