<?php
//Change the value of PAYTM_MERCHANT_KEY constant with details received from Paytm.
define('PAYTM_MERCHANT_KEY', 'S4JDQ0zzWQD#L9b5'); 
?>
