<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
class Astrologer extends  REST_Controller {

	public function __construct()
	{
		parent::__construct(); 
		$this->load->model(array('astrologer_model'));
	    
	}

	public function list_post()
	{	
 		
		 $param 				 =  array('status'=>'1');
		 $res_array              =  $this->astrologer_model->get_astrologer($param);	
		 
		$this->response([
                    'status' => 1,
                    'message' => 'successful.',
                    'data' => $res_array
                ], REST_Controller::HTTP_OK);
	}
	
	public function profile(){
		
		$id = (int) $this->uri->segment(3);
		$param     = array('status'=>'1','where'=>"astrologer_id ='$id' ");	
		$res       = $this->astrologer_model->get_astrologer(1,0,$param);	
		if(is_array($res) && !empty($res)){			
			$data['title'] = 'astrologer Detail';
		    $data['res'] = $res; 
			
			echo $res['astrologer_details'];			
		    //$this->load->view('astrologer/view_detail_astrolger',$data);
		
			
		}
		/*$id = (int) $this->uri->segment(3);		
		$param     = array('status'=>'1','where'=>"astrologer_id ='$id' ");	
		$res       = $this->astrologer_model->get_astrologer(1,0,$param);	
		
		if(is_array($res) && !empty($res))
		{			
			$data['title'] = 'astrologer Detail';
		    $data['res'] = $res; 			
		    $this->load->view('astrologer/view_detail_astrolger',$data);
		
			
		}else
		{
			redirect('astrologer', ''); 
			
		}*/
	}
	
	public function popdetail(){
		
		
	    $id = (int) $this->uri->segment(3);
		$param     = array('status'=>'1','where'=>"astrologer_id ='$id' ");	
		$res       = $this->astrologer_model->get_astrologer(1,0,$param);	
		//if(is_array($res) && !empty($res)){			
			$data['title'] = 'astrologer Detail';
		    $data['res'] = $res; 
			
			echo $res['astrologer_details'];
			//print_r($res);			
		    //$this->load->view('astrologer/view_detail_astrolger',$data);
		
			
		//}	
		
	}
	
	public function detail(){
		 $Id = (int) $this->uri->segment(3);
		 $newdata = array(
			'astro_id'  => $Id,
			'redirect' => TRUE
		 );
		 $this->session->set_userdata($newdata);	
		 redirect('call_package','');	
	}
	
	
}
?>