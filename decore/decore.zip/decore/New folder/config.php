<?php
class DB {
	
	protected $db_host = 'localhost';
	protected $db_user = 'astropat_seoind';
	protected $db_pass = '?#seoindiuH#2';
	protected $db_name = 'astropat_Newpat';
	
	
	
	protected $conn;
	// Open a connect to the database.
	// Make sure this is called on every page that needs to use the database.
	public function connect() {
		mysqli_report(MYSQLI_REPORT_STRICT); 
		
		try { 
		$this->conn= new mysqli($this->db_host, $this->db_user, $this->db_pass, $this->db_name);
		if ($this->conn->connect_error) {
    		die("Connection failed: " . $this->conn->connect_error);
			} 
		}
		catch (mysqli_sql_exception $e) {
      		throw $e;
	  	}
		
		return $this->conn;
		//return true;
	}

}

// set time and date for indian
date_default_timezone_set('Asia/Kolkata');
$date_time = date('Y-m-d h:i:s ', time());
$date=date('Y-m-d');
$time=time();

?>