<?php

include("config.php");
include("modules/user.class.php");
include("modules/astrologer.class.php");


$usrObj = new user;
$astrologer = new Astrologer;

header('Content-Type: application/json');
$action = $_REQUEST['action'];

switch($action){
  
  case "AstrologerListing" : 
     echo $response = $astrologer->astrologerListing($_REQUEST);
  break; 
  
   case "AstrologerDetail" : 
     echo $response = $astrologer->astrologerDetail($_REQUEST);
  break; 
  
}




//echo json_decode($response);


?>