<?php
include_once('config.php');
class user extends DB{

	function __construct(){
		$this->connect();
	}
	
	function loginAction($fields){
		
		
		$response = array();
		//$result = $this->conn->query($sql);
		$select_query = mysqli_query($this->conn,"Select * from wl_employe where employe_email='".$fields['userName']."'");
		$chk_user = mysqli_num_rows($select_query);
		
		if($chk_user > 0){
		$rec = mysqli_fetch_array($select_query);
		
		if( $rec['password'] == $fields['pass'] ){
		  
		  //$response['Result'] = array("success"=>1,"code"=>0);
		  $response = array("status"=>1);
		  $response['Result']= array(
		  				'employe_id'=>$rec['employe_id'],
						 'employeuniq_id'=>$rec['employeuniq_id'],
						 'employe_name'=>$rec['employe_name'],
						 "employe_phone"=>$rec['employe_phone'],"office_name"=>$rec['office_name'],"role"=>$rec['role']);
		}else{
		
		   $response = array("status"=>0,'message'=>"Invalid password");
		}
		}else{
		$response = array("status_code"=>0,"status"=>0,'message'=>"Invalid user");
		}
		return json_encode($response);

	}
	
	
	
function registerUser($fields){
    if($fields['email']=="" || $fields['pass']==""){
        $response = array("success"=>0,"code"=>0,"message"=>"Email ID or password can not be blank");
    }else{
        $check_user = mysqli_query($this->conn,"Select * from wl_employe where employe_email='".$fields['email']."'");
        $num_rows = mysqli_num_rows($check_user);
        if($num_rows > 0){
            $response['Result'] = array("status"=>0,"message"=>"This email id is already registered");
        }else{
            $sql="INSERT INTO wl_employe (`employe_name`,`employe_image`,`employe_email`,`password`,`employe_phone`,`employe_desination`,`employe_dob`,`employe_address`,`office_name`,`role`) VALUE ('".$fields['name']."','".$fields['img']."','".$fields['email']."','".$fields['pass']."','".$fields['phone']."','".$fields['desination']."','".$fields['dob']."','".$fields['address']."','".$fields['office']."','".$fields['role']."')";
            $insert_qry = mysqli_query($this->conn,$sql);
            $response['Result'] = array("success"=>1,"code"=>0,"msg"=>"Item has been added");
        }
    }
    return json_encode($response);
}
	

	function forgotPassword($fields){
	  $check_user = mysqli_query($this->conn,"Select * from wl_employe where employe_email='".$fields['email']."'");
      $num_rows = mysqli_num_rows($check_user);
	   
	   if($num_rows > 0){
	    $rec = mysqli_fetch_array($check_user);
		// multiple recipients
		$to  = $fields['email']; // note the comma
		
		// subject
		$subject = 'Forgot Password';
		$rand = $rec['password'];
		//$update_user = mysql_query("update users set password='".$rand."' where email='".$fields['email']."'");
		
		// message
		$message = '
		
		<p>Here is the password!</p>
		<table>
		
		<tr>
		<td>Password : </td> <td>'.$rand.'</td>
		</tr>
		</table>
		
		';
		
		// To send HTML mail, the Content-type header must be set
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		
		// Additional headers
		$headers .= 'From: Info' . "\r\n";
		
		// Mail it
		$ismail = mail($to, $subject, $message, $headers);
	   	
	   	if($ismail){
	   		$response = array("status"=>1,"Message"=>"Email Sent");

	   	}else{
	        $response = array("status"=>1,"Message"=>"Email Not Sent");
	        }
	   
	   
	   }else{
	   	        $response = array("status"=>0,"Message"=>"Email Id Not Registred");

	   } 
		    return json_encode($response);

	}
	
	
	
	function userDetail($fields){
		
		$response = array();
		$select_query = mysqli_query($this->conn,"Select * from wl_employe where employe_id='".$fields['user_id']."'");
		$rec = mysqli_fetch_array($select_query);
		
		$response['Result'] = array("status"=>1);
		$response['Result']['user_data'][] = array('name'=>$rec['employe_name'],'employe_phone'=>$rec['employe_phone'],"office_name"=>$rec['office_name'],"email"=>$rec['employe_email']);
		
		return json_encode($response);
	
	}
	
	
	function changepassword($fields){
		$response = array();
		
		if($fields['oldpw']=="" || $fields['newpw']=="" || $fields['conpw']==""){
	      $response = array("status"=>0,"message"=>"Password Fields cannot Blank");
	      }else{
        $pw=$this->conn->query("select password from wl_employe where employe_id= '" . $fields["user_id"] . "'");
                $row = $pw->fetch_object();
                $pawo = $row->password ; 
		
		if($fields['oldpw']== $pawo){
        if ($fields['newpw']==$fields['conpw']){
         $this->conn->query("UPDATE wl_employe SET password='" . $fields['newpw'] . "' WHERE employe_id='" . $fields['user_id'] . "'");
		 $response['Result'] = array("status"=>1,"message"=>"successfully changed");
         }
        else { 
			//echo ""; 
			$response['Result'] = array("status"=>0,"message"=>"Passwords do not match");
			}
        }else { 
		$response['Result'] = array("status"=>0,"message"=>"Wrong password entered");
		  //echo "";
		}
    }
	return json_encode($response);
   }
 
 
 
 function attendance_in($fields){
	  
	     if($fields['user_id']=="" || $fields['date']=="" || $fields['status']=="" || $fields['in_timing']==""){
	      $response = array("status"=>0,"message"=>"User ID or date can not be blank");
	      
		  }else{
             
             $check_user = mysqli_query($this->conn,"Select * from wl_attendance where employ_id='".$fields['user_id']."' AND created_at='".$fields['date']."'");
             $num_rows = mysqli_num_rows($check_user);
             if($num_rows > 0){
             $response = array("status"=>0,"message"=>"Today Attendance already registered");
            
			 }else{
	   	     
			 $sql="INSERT INTO wl_attendance (`employ_id`,`created_at`,`in_timing`,`status`) VALUE ('".$fields['user_id']."','".$fields['date']."','".$fields['in_timing']."','".$fields['status']."')";
	     
		    $insert_qry = mysqli_query($this->conn,$sql);
	     	$response = array("status"=>1,"message"=>"Done");
            if($insert_qry){
	     	    $user_id1 = mysqli_insert_id($this->conn);
	     	   // $response['response']['success'] = 1;
			$response['response'] = array("id"=>$user_id1);
	     	     
	     	}	
	     }
	    }
	    return json_encode($response);
			 
	  }
	
	
	  
	  function attendance_list($fields){
	  
	     if($fields['user_id']==""){
	      $response = array("status"=>0,"message"=>"User ID or date can not be blank");
	      }else{
             $myArray = array();
			  $sql="Select * from wl_attendance where employ_id='".$fields['user_id']."'"; 
             
			 $check_user = mysqli_query($this->conn,$sql);
			 $chk_user = mysqli_num_rows($check_user);
               if($chk_user > 0){
        		$arr['Result'] = array("success"=>1,"code"=>0);	
        		}else{
        		$arr['Result'] = array("success"=>0,"code"=>0);	
        		}
			   while($rec=mysqli_fetch_array($check_user)){
			   $arr['Result']['data'][] = array('id'=>$rec['id'],'employe_id'=>$rec['employ_id'],
			   'date'=>$rec['created_at'],'in_timing'=>$rec['in_timing'],'out_timing'=>$rec['out_timing'],'status'=>$rec['status']);
		    }
         }
		 
	    return json_encode($arr,JSON_UNESCAPED_SLASHES);
			 
	  }
	  
	 function attendance_out($fields){
	  
	     if($fields['user_id']=="" || $fields['date']=="" || $fields['date']=="employ_id"){
	      $response = array("status"=>0,"message"=>"User ID or date can not be blank");
	      }else{
           $sql="UPDATE `wl_attendance` SET out_timing='".$fields['out_timing']."'   where employ_id='".$fields['user_id']."' AND created_at='".$fields['date']."'";
			 
             $check_user = mysqli_query($this->conn,$sql);
             
             $response = array("status"=>1,"message"=>"Done");
             if($insert_qry){
	     	    $user_id1 = mysqli_insert_id($this->conn);
	     	   // $response['response']['success'] = 1;
			 $response['response'] = array("id"=>$user_id1);
	     	     
	     	
	     }
	    }
	    return json_encode($response);
	 }  
	
	function user_listing($fields){
		
		if($fields['role']==""){
	      $response = array("status"=>0,"message"=>"User ID or date can not be blank");
	      }else{
		   $myArray['Result'] = array("success"=>1,"code"=>0); 
		  
		   if($fields['role']==='admin'){ 
           $sql="SELECT * FROM `wl_employe` where role!='admin'";
		   }
		   if($fields['role']==='manager'){ 
           $sql="SELECT * FROM `wl_employe` where role='emp'";
		   }
		   $result = mysqli_query($this->conn,$sql);
		   
		   if (mysqli_num_rows($result) > 0) {
                while($row = mysqli_fetch_assoc($result)) {
                    $myArray['Result']['data'][] = $row;
                }
		   }else{
		       $myArray['Result']['success'] = 0;
		   }
           $response=json_encode($myArray);
         }
	    return $response;
		
		} 
 
 }





?>